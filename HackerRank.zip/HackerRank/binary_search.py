
def binary_search(array, target_num):
    """
    This functions executes a binary search on a sorted list.

    Time Complexity: O(log n)
    Space Complexity: O(1)
    """
    left_num = 0
    right_num = len(array) - 1

    while left_num <= right_num:
        middle_num = (left_num + right_num) // 2

        if array[middle_num] == target_num:
            return middle_num
        elif array[middle_num] < target_num:
            left_num = middle_num + 1
        else:
            right_num = middle_num - 1
    return -1


if __name__ == "__main__":
    num_input = int(input().strip())
    array = list(map(int, input().split()))
    target_num = int(input().strip())

    result = binary_search(array, target_num)
    print(result)
