# Binary Search Implementation (Python)

## Overview
This project demonstrates a practical implementation of the a Binary Search algorithm using Python.  
Binary search is a highly efficient algorithm used to locate a target value within a sorted array by repeatedly dividing the search interval in half.  

The project includes:
- A clean Python implementation of the binary search algorithm.
- User input handling for array and target value.
- A professional, modular code structure suitable for technical assessments and portfolio showcase.

This project is ideal for demonstrating algorithmic understanding, problem-solving skills, and efficiency awareness in software engineering and data analysis contexts.

---

## Objective
The main objectives of this project are to:

1. Implement a **binary search algorithm** correctly.
2. Understand and demonstrate **time and space complexity analysis**.
3. Build **clean, maintainable Python code** that can be easily tested and reviewed.
4. Provide a foundation for solving similar search-related problems efficiently.

---

## Features
- Accepts a **user-provided sorted array** and target value.
- Returns the **index** of the target if found.
- Returns **-1** if the target does not exist in the array.
- Handles **large datasets efficiently**.
- Designed to be compatible with **HackerRank and other coding platforms**.

---

## Time and Space Complexity

Time Complexity = O(log n)
~Each iteration halves the search space, resulting in logarithmic runtime.

Space Complexity = O(1)
~The algorithm uses a fixed amount of memory regardless of input size.

---

## Example Usage
**Input**
6
2 4 6 8 10 12
8

**Output**
3

**Explanation**
The target number 8 is located at index 3 in the sorted array [2 4 6 8 10 12]

---

## How to Run
1. Clone the repository:
    
    git clone https://github.com/yourusername/binary-search-python.git
    cd binary-search-python

2. Run the python script:

   python binary_search.py 

3. Enter the number of elements, the sorted array, and the target value as prompted.
