from django.contrib.auth.models import Group, Permission
from django.db.models.signals import post_migrate, post_save
from django.conf import settings
from django.dispatch import receiver
from django.core.mail import send_mail
from django.contrib.auth import get_user_model
from .models import Article, CustomUser, Newsletter
from django.contrib.contenttypes.models import ContentType
import requests
from requests.exceptions import RequestException


User = get_user_model()

@receiver(post_migrate)
def create_user_roles(sender, **kwargs):
    """
    Automatically create role-based groups and assign permissions
    after migrations are applied.
    """
    roles = {
        "Reader": [],
        "Editor": ["change_article", "delete_article"],
        "Journalist": ["add_article", "change_article", "delete_article"],
    }

    for role, perms in roles.items():
        group, _ = Group.objects.get_or_create(name=role)
        for codename in perms:
            try:
                perm = Permission.objects.get(codename=codename)
                group.permissions.add(perm)
            except Permission.DoesNotExist:
                pass


@receiver(post_save, sender=CustomUser)
def handle_user_role_change(sender, instance, **kwargs):
    """
    Signal to clear irrelevant data when a user's role is updated.
    - Clears subscriptions if the role is 'journalist'.
    """
    if instance.role == 'journalist':
        instance.subscriptions_to_publishers.clear()
        instance.subscriptions_to_journalists.clear()


@receiver(post_save, sender=Article)
def notify_on_approval(sender, instance, created, **kwargs):
    """
    Sends an email to subscribers and posts to Twitter when an
    article is approved.

    Args:
        instance (Article): The approved article instance.
        created (bool): Whether the article was just created.
    """
    if instance.is_approved:
        try:
            readers = instance.publisher.subscribed_readers.all()
        except AttributeError:
            readers = []

        try:
            journalist = instance.journalist
            journalist_followers = journalist.journalist_followers.all()

        except AttributeError:
            journalist_followers = []

        subscribers = readers.union(journalist_followers)

        for user in subscribers:
            send_mail(
                subject=f"New Article: {instance.title}",
                message=instance.content,
                from_email="no-reply@newsapp.com",
                recipient_list=[user.email],
                fail_silently=True,
            )

        # Post to Twitter (or a stub if API not available)
        try:
            requests.post(
                "https://api.twitter.com/...",  # Replace with actual endpoint
                data={'content': f"{instance.title}\n{instance.content}"}
            )
        except RequestException as e:
            print(f"Twitter post failed: {e}")


@receiver(post_save, sender=CustomUser)
def assign_group_and_permissions(sender, instance, created, **kwargs):
    if not created:
        return  # Only assign group/permissions when user is first created

    role = instance.role

    if role not in ['reader', 'editor', 'journalist']:
        return

    group, created = Group.objects.get_or_create(name=role)

    if created:
        if role == 'reader':
            perms = ['view_article', 'view_newsletter']

        elif role == 'editor':
            perms = [
                'view_article', 'change_article', 'delete_article',
                'view_newsletter', 'change_newsletter', 'delete_newsletter'
            ]

        elif role == 'journalist':
            perms = [
                'add_article', 'view_article',
                'change_article', 'delete_article',
                'add_newsletter', 'view_newsletter',
                'change_newsletter', 'delete_newsletter'
            ]

        # Add permissions to group
        for model in [Article, Newsletter]:
            content_type = ContentType.objects.get_for_model(model)
            for codename in perms:
                try:
                    permission = Permission.objects.get(
                                                        codename=codename,
                                                        content_type=content_type
                                                    )
                    group.permissions.add(permission)
                except Permission.DoesNotExist:
                    continue

    # Add user to group
    instance.groups.add(group)


@receiver(post_save, sender=Article)
def notify_on_article_approval(sender, instance, created, **kwargs):
    if not created and instance.is_approved:
        journalist = instance.journalist
        publisher = instance.publisher

        # Get readers subscribed to the journalist
        journalist_followers = journalist.journalist_followers.all()

        # Get readers subscribed to the publisher
        publisher_followers = publisher.subscribed_readers.all() if publisher else []

        # Merge and deduplicate recipients
        subscribers = set(journalist_followers) | set(publisher_followers)

        subject = f"New Article Approved: {instance.title}"
        message = f"""
        {instance.title}\n
        {instance.content[:300]}...\n
        Read more in the NewsApp.
        """

        for user in subscribers:
            if user.email:
                send_mail(
                    subject,
                    message,
                    settings.DEFAULT_FROM_EMAIL,
                    [user.email],
                    fail_silently=True
                )
