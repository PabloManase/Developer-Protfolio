from django.test import TestCase
from rest_framework.test import APIClient
from .models import CustomUser, Article


class ArticleAPITest(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.journalist = CustomUser.objects.create_user(
            username='journalist', password='pass123', role='journalist'
        )
        self.article = Article.objects.create(
            title='Test Article',
            content='Sample content',
            journalist=self.journalist,
            is_approved=True
        )

    def test_article_list_api(self):
        response = self.client.get('/api/articles/')
        self.assertEqual(response.status_code, 200)
        self.assertIn('Test Article', str(response.content))
