from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import user_passes_test, login_required
from .decorators import role_required
from django.contrib import messages
from django.core.mail import send_mail

from .models import Article, CustomUser, Publisher, Newsletter
from .forms import (
    CustomUserCreationForm,
    ArticleForm,
    NewsletterForm,
    PublisherForm
)


def register_user(request):
    """
    Handle user registration.
    Creates a new user and logs them in upon successful registration.
    """
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = CustomUserCreationForm()
    return render(request, 'news_app/register.html', {'form': form})


def login_user(request):
    """
    Authenticate and log in a user.
    """
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('home')
    return render(request, 'news_app/login.html')


@login_required
def logout_user(request):
    """
    Log out the current user.
    """
    logout(request)
    return redirect('login')


@login_required
@role_required(['editor'])
@user_passes_test(lambda u: u.role == 'editor')
def approve_article(request, article_id):
    """
    Allow editors to approve submitted articles.
    """
    article = get_object_or_404(Article, id=article_id)
    article.is_approved = True
    article.save()
    return redirect('home')


def home(request):
    """
    Render the homepage.
    """
    return render(request, 'news_app/home.html')


def article_list(request):
    """
    List all approved articles.
    """
    articles = Article.objects.filter(is_approved=True)
    return render(request, 'news_app/article_list.html',
                  {'articles': articles})


def is_journalist(user):
    return user.is_authenticated and user.role == 'journalist'


@login_required
@role_required(['journalist'])
@user_passes_test(is_journalist)
def submit_article(request):
    """
    Allow journalists to submit new articles.
    """
    if request.method == 'POST':
        form = ArticleForm(request.POST)
        if form.is_valid():
            article = form.save(commit=False)
            article.journalist = request.user
            article.save()
            return redirect('article_list')
    else:
        form = ArticleForm()
    return render(request, 'news_app/submit_article.html', {'form': form})


@login_required
@user_passes_test(lambda u: u.role in ['admin', 'editor'])
def create_publisher(request):
    """
    Allow admins or editors to create a new publisher.
    """
    if request.method == 'POST':
        form = PublisherForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Publisher created successfully.')
            return redirect('article_list')
    else:
        form = PublisherForm()
    return render(request, 'publishers/create_publisher.html', {'form': form})


@login_required
def subscribe_to_publisher(request, publisher_id):
    """
    Allow readers to subscribe to a publisher.
    """
    publisher = get_object_or_404(Publisher, id=publisher_id)
    if request.user.role == 'reader':
        request.user.subscriptions_to_publishers.add(publisher)
    return redirect('article_list')


@login_required
def subscribe_to_journalist(request, journalist_id):
    """
    Allow readers to subscribe to a journalist.
    """
    journalist = get_object_or_404(CustomUser, id=journalist_id)
    if request.user.role == 'reader':
        request.user.subscriptions_to_journalists.add(journalist)
    return redirect('article_list')


@login_required
@role_required(['journalist'])
@user_passes_test(lambda u: u.role == 'journalist')
def create_newsletter(request):
    """
    Allow journalists to create a newsletter and send it to their followers.
    """
    if request.method == 'POST':
        form = NewsletterForm(request.POST)
        if form.is_valid():
            newsletter = form.save(commit=False)
            newsletter.created_by = request.user
            newsletter.save()
            subscribers = request.user.journalist_followers.all()
            for reader in subscribers:
                send_mail(
                    f"Newsletter: {newsletter.title}",
                    newsletter.content,
                    'no-reply@newsapp.com',
                    [reader.email],
                    fail_silently=True
                )
            return redirect('article_list')
    else:
        form = NewsletterForm()
    return render(request, 'news_app/create_newsletter.html', {'form': form})


@login_required
def reader_dashboard(request):
    """
    Display a dashboard for readers with articles from followed
    journalists and publishers.
    """
    if request.user.role != 'reader':
        return redirect('home')
    followed_journalists = request.user.subscriptions_to_journalists.all()
    followed_publishers = request.user.subscriptions_to_publishers.all()
    articles = Article.objects.filter(is_approved=True).filter(
        journalist__in=followed_journalists
    ) | Article.objects.filter(
        is_approved=True,
        publisher__in=followed_publishers
    )
    articles = articles.order_by('-id')
    context = {
        'followed_journalists': followed_journalists,
        'followed_publishers': followed_publishers,
        'articles': articles.distinct(),
    }
    return render(request, 'news_app/reader_dashboard.html', context)


@login_required
@role_required(['journalist'])
def journalist_dashboard(request):
    """
    Display a dashboard for journalists with their articles and followers.
    """
    if request.user.role != 'journalist':
        return redirect('home')
    articles = request.user.articles_written.all()
    followers = request.user.journalist_followers.all()
    return render(request, 'news_app/journalist_dashboard.html', {
        'articles': articles,
        'followers': followers
    })


@login_required
@user_passes_test(lambda u: u.role == 'editor')
def editor_dashboard(request):
    """
    Display a dashboard for editors with all unapproved
    articles and newsletters.
    """
    articles = Article.objects.filter(is_approved=False)
    newsletters = Newsletter.objects.all()  # Adjust if approval is required
    return render(request, 'news_app/editor_dashboard.html', {
        'articles': articles,
        'newsletters': newsletters
    })


@user_passes_test(lambda u: u.role == 'journalist')
def newsletter_list(request):
    """
    Display a list of newsletters created by the current journalist.
    """
    newsletters = request.user.newsletter_set.all()
    return render(request, 'news_app/newsletter_list.html',
                  {'newsletters': newsletters})


@login_required
@role_required(['journalist', 'editor'])
@user_passes_test(lambda u: u.role == 'journalist')
def update_newsletter(request, pk):
    """
    Allow journalists to update an existing newsletter.
    """
    newsletter = get_object_or_404(request.user.newsletter_set, pk=pk)
    if request.method == 'POST':
        form = NewsletterForm(request.POST, instance=newsletter)
        if form.is_valid():
            form.save()
            return redirect('newsletter_list')
    else:
        form = NewsletterForm(instance=newsletter)
    return render(request, 'news_app/update_newsletter.html', {'form': form})


@user_passes_test(lambda u: u.role == 'journalist')
def delete_newsletter(request, pk):
    """
    Allow journalists to delete a newsletter.
    """
    newsletter = get_object_or_404(request.user.newsletter_set, pk=pk)
    if request.method == 'POST':
        newsletter.delete()
        return redirect('newsletter_list')
    return render(request, 'news_app/delete_newsletter.html',
                  {'newsletter': newsletter})
