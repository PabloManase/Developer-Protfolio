from django.db import models
from django.contrib.auth.models import AbstractUser


class CustomUser(AbstractUser):
    """
    Custom user model extending Django's AbstractUser.

    Attributes:
        role (str): The user's role in the system ('reader', 'editor',
                    or 'journalist').
        subscriptions_to_publishers: Publishers the reader is
                                     subscribed to.
        subscriptions_to_journalists: Journalists the reader is
                                      subscribed to.
    """

    ROLE_CHOICES = (
        ('reader', 'Reader'),
        ('editor', 'Editor'),
        ('journalist', 'Journalist'),
    )

    role = models.CharField(max_length=20, choices=ROLE_CHOICES)

    subscriptions_to_publishers = models.ManyToManyField(
        'Publisher',
        blank=True,
        related_name='subscribed_readers'
    )

    subscriptions_to_journalists = models.ManyToManyField(
        'self',
        blank=True,
        symmetrical=False,
        related_name='journalist_followers'
    )

    def __str__(self):
        return self.username


class Publisher(models.Model):
    """
    Represents a publishing company or organization.

    Attributes:
        name (str): Name of the publisher.
        editors (ManyToMany): Editors associated with this publisher.
        journalists (ManyToMany): Journalists associated with this publisher.
    """

    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    editors = models.ManyToManyField(
        CustomUser,
        related_name='publisher_editors'
    )

    journalists = models.ManyToManyField(
        CustomUser,
        related_name='publisher_journalists'
    )

    def __str__(self):
        return self.name


class Article(models.Model):
    """
    Represents a news article submitted by a journalist.

    Attributes:
        title (str): Title of the article.
        content (str): Body content of the article.
        journalist (ForeignKey): Author of the article (CustomUser).
        publisher (ForeignKey): Publisher associated with the article.
        is_approved (bool): Approval status of the article.
    """

    title = models.CharField(max_length=255)
    content = models.TextField()

    journalist = models.ForeignKey(
        CustomUser,
        on_delete=models.CASCADE,
        related_name='articles_written'  # Fix for dashboard error
    )

    publisher = models.ForeignKey(
        Publisher,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    is_approved = models.BooleanField(default=False)

    def __str__(self):
        return self.title


class Newsletter(models.Model):
    """
    Model representing a newsletter publication.

    Attributes:
        title (str): The title of the newsletter.
        content (str): The body content of the newsletter.
        created_by (CustomUser): The user who authored the newsletter.
        created_at (datetime): Timestamp when newsletter was created.
    """

    title = models.CharField(max_length=200)
    content = models.TextField()
    created_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
