from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser, Article, Newsletter, Publisher


class CustomUserCreationForm(UserCreationForm):
    """
    Form for registering new users with role selection.
    Inherits from Django's built-in UserCreationForm.
    """
    class Meta:
        model = CustomUser
        fields = ('username', 'email', 'role', 'password1', 'password2')
        labels = {
            'username': 'Username',
            'email': 'Email Address',
            'role': 'User Role',
            'password1': 'Password',
            'password2': 'Confirm Password',
        }


class ArticleForm(forms.ModelForm):
    """
    Form for journalists to submit or edit articles.
    """
    class Meta:
        model = Article
        fields = ['title', 'content', 'publisher']
        labels = {
            'title': 'Article Title',
            'content': 'Content',
            'publisher': 'Publisher',
        }
        widgets = {
            'content': forms.Textarea(attrs={'rows': 6}),
        }


class NewsletterForm(forms.ModelForm):
    """
    Form for creating or editing newsletters.
    """
    class Meta:
        model = Newsletter
        fields = ['title', 'content']
        labels = {
            'title': 'Newsletter Title',
            'content': 'Body Content',
        }
        widgets = {
            'content': forms.Textarea(attrs={'rows': 6}),
        }


class PublisherForm(forms.ModelForm):
    """
    Form for creating a new publisher.
    Used by editors or admin users.
    """
    class Meta:
        model = Publisher
        fields = ['name', 'description']
        labels = {
            'name': 'Publisher Name',
            'description': 'Brief Description',
        }
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
        }
