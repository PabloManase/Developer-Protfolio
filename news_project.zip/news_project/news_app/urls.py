from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from rest_framework.routers import DefaultRouter
from .api_views import ArticleViewSet
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)

# API router registration
router = DefaultRouter()
router.register(r'api/articles', ArticleViewSet)

# Core web routes
urlpatterns = [
     # Authentication
     path('register/', views.register_user, name='register'),
     path('login/', views.login_user, name='login'),
     path('logout/', views.logout_user, name='logout'),

     # Homepage and articles
     path('', views.home, name='home'),
     path('articles/', views.article_list, name='article_list'),
     path('submit/', views.submit_article, name='submit_article'),
     path('approve/<int:article_id>/', views.approve_article,
          name='approve_article'),

     # Subscriptions
     path('subscribe/publisher/<int:publisher_id>/',
          views.subscribe_to_publisher, name='subscribe_publisher'),
     path('subscribe/journalist/<int:journalist_id>/',
          views.subscribe_to_journalist, name='subscribe_journalist'),

     # Newsletters
     path('newsletter/create/', views.create_newsletter,
          name='create_newsletter'),
     path('newsletters/', views.newsletter_list, name='newsletter_list'),
     path('newsletters/<int:pk>/edit/', views.update_newsletter,
          name='update_newsletter'),
     path('newsletters/<int:pk>/delete/', views.delete_newsletter,
          name='delete_newsletter'),

     # Dashboards
     path('dashboard/reader/', views.reader_dashboard,
          name='reader_dashboard'),
     path('dashboard/journalist/', views.journalist_dashboard,
          name='journalist_dashboard'),
     path('dashboard/editor/', views.editor_dashboard,
          name='editor_dashboard'),

     # Publishers
     path('publishers/create/', views.create_publisher,
          name='create_publisher'),
]

# JWT Auth API endpoints
urlpatterns += [
    path('api/token/', TokenObtainPairView.as_view(),
         name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(),
         name='token_refresh'),
]

# Password reset endpoints
urlpatterns += [
    path('password-reset/', auth_views.PasswordResetView.as_view(
        template_name='news_app/password_reset.html'), name='password_reset'),

    path('password-reset/done/', auth_views.PasswordResetDoneView.as_view(
        template_name='news_app/password_reset_done.html'),
        name='password_reset_done'),

    path(
          'reset/<uidb64>/<token>/',
          auth_views.PasswordResetConfirmView.as_view(
               template_name='news_app/password_reset_confirm.html'
          ),
          name='password_reset_confirm'
     ),

    path(
          'reset/done/',
          auth_views.PasswordResetCompleteView.as_view(
               template_name='news_app/password_reset_complete.html'
          ),
          name='password_reset_complete'
     ),
]

# API routes (router)
urlpatterns += router.urls
