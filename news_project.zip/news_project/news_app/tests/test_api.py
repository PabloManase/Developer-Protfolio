from django.urls import reverse
from rest_framework.test import APITestCase
from rest_framework_simplejwt.tokens import RefreshToken
from news_app.models import CustomUser, Publisher, Article


class ArticleAPITest(APITestCase):
    def setUp(self):
        self.reader = CustomUser.objects.create_user(
                                                     username="reader",
                                                     password="readerpass",
                                                     role="reader"
                                                    )
        self.journalist = CustomUser.objects.create_user(
                                                         username="journalist",
                                                         password="journalistpass",
                                                         role="journalist"
                                                        )
        self.publisher = Publisher.objects.create(name="Tech News")
        self.publisher.journalists.add(self.journalist)

        self.reader.subscriptions_to_journalists.add(self.journalist)
        self.reader.subscriptions_to_publishers.add(self.publisher)

        self.article = Article.objects.create(
            title="Breaking Tech",
            content="AI is taking over.",
            journalist=self.journalist,
            publisher=self.publisher,
            is_approved=True
        )

        self.token = RefreshToken.for_user(self.reader).access_token
        self.client.credentials(HTTP_AUTHORIZATION=f'Bearer {self.token}')

    def test_retrieve_subscribed_articles(self):
        response = self.client.get(reverse('article-list'))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]['title'], "Breaking Tech")
