default_app_config = "news_app.apps.NewsAppConfig"
