from django.shortcuts import redirect
from django.core.exceptions import PermissionDenied


def role_required(allowed_roles=[]):
    def decorator(view_func):
        def wrapper_func(request, *args, **kwargs):
            if (
                request.user.is_authenticated
                and request.user.role
                in allowed_roles
            ):
                return view_func(request, *args, **kwargs)

            raise PermissionDenied

        return wrapper_func

    return decorator
