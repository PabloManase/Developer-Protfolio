from rest_framework import serializers
from .models import Article, CustomUser, Publisher


class ArticleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Article
        fields = [
                    '__all__',
                    'id',
                    'title',
                    'content',
                    'journalist',
                    'publisher',
                    'is_approved'
                ]
