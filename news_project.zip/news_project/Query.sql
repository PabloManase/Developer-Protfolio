CREATE USER 'new_user'@'localhost' IDENTIFIED WITH mysql_native_password BY 'strong_password';
GRANT ALL PRIVILEGES ON news_project.* TO 'new_user'@'localhost';
FLUSH PRIVILEGES;
