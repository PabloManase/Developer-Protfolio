from rest_framework import viewsets, permissions
from rest_framework.response import Response
from rest_framework.decorators import action
from .models import Article
from .serializers import ArticleSerializer


class ArticleViewSet(viewsets.ReadOnlyModelViewSet):
    """
    API endpoint that allows users to retrieve articles
    from publishers or journalists they are subscribed to.
    """
    serializer_class = ArticleSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        queryset = Article.objects.filter(is_approved=True)

        if user.role == 'reader':
            publisher_ids = user.subscriptions_to_publishers.values_list('id', flat=True)
            journalist_ids = user.subscriptions_to_journalists.values_list('id', flat=True)

            return queryset.filter(
                publisher_id__in=publisher_ids
            ) | queryset.filter(
                journalist_id__in=journalist_ids
            )

        return queryset.none()
